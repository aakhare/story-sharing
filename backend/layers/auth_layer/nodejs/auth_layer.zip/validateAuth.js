import jwt from 'jsonwebtoken';


export default async(token, TOKEN_SECRET)=>{
    const verify = await jwt.verify(token, TOKEN_SECRET);
    return verify;
}